# DATT3300_mirrored_balls

Hey guys, this is our GIT. Right now, the only scene is the test scene - this is just where I've been playing around with the code and stuff.

To create a level at the moment:
The platforms need to be connected to the buttons in the unity editor. After selecting the platform you want to control, drag the button you want to use from the unity editor on top of the field reading "Button" under the "Green Platform" script. This should link the two, switching them on a Q press. If you want an object to start invisible, let me know and I'll need to add that implementation.
If there's any code questions, let me know!
